CREATE TABLE Water_System (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Device_id VARCHAR(64),system_state VARCHAR(64) 
    );
INSERT INTO `Water_System`(`Device_id`,`system_state`) VALUES ("709cnaB","ON");

CREATE TABLE Tank_details (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Device_id VARCHAR(64),User_id VARCHAR(64), tank_capacity VARCHAR(64), tank_fill VARCHAR(64) 
    );
INSERT INTO `Tank_details`(`Device_id`,`User_id`, `tank_capacity`,`tank_fill`) VALUES ("709cnaB","1","2000L","78%");

CREATE TABLE User_details (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    User_id VARCHAR(64),email VARCHAR(64), firstname VARCHAR(64), lastname VARCHAR(64), Tank_fill VARCHAR(64) 
    );
INSERT INTO `User_details`(`User_id`,`email`, `firstname`,`firstname`) VALUES ("123","+917042653792ashraumair21@gmail.com","Umair", "Ashraf");

CREATE TABLE Multi_users (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    User_id VARCHAR(64), user2 VARCHAR(64), user3 VARCHAR(64), user4 VARCHAR(64),
    );
INSERT INTO `Multi_users` (`user2`, `user3`) 
VALUES ("umair.ashraf1996@gmail.com", "teksnaindia@gmail.com")
WHERE User_id = 123;


/* OLD TABLES

CREATE TABLE Users (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(64),
    device_name VARCHAR(64),
    town INT(6),
    email VARCHAR(64),
    device_state VARCHAR(64),
    Tank_quantity INT(6),
    System_state INT(6),
    password VARCHAR(64)
);
INSERT INTO `Users`(`name`,`device_name`, `town`, `email`,`device_state`,`Tank_quantity`,`System_state`,`password`) VALUES ("Tabrez","Device1", 1,"ashrafumair21@gmail.com" , "ON",30,0,"umair");

CREATE TABLE Towns (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    town INT(6),townname VARCHAR(64),City INT(6),State INT(6),supply_state VARCHAR(64),
    supply_OFF TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    supply_ON TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
INSERT INTO `Towns`(`town`,`townname`,`City`,`State`,`supply_state`) VALUES (1,"shahganj",1,1,"OFF");

CREATE TABLE Cities (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    City INT(6),cityname VARCHAR(64) 
);
INSERT INTO `Cities`(`City`,`cityname`) VALUES (1,"Agra");

CREATE TABLE States (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    State INT(6),statename VARCHAR(64) 
);
INSERT INTO `States`(`State`,`statename`) VALUES (1,"UP");
*/
