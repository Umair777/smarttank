#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <Arduino_JSON.h>
#include <ESP8266WiFiMulti.h>
ESP8266WiFiMulti WiFiMulti;

String apiKeyValue = "tPmAT5Ab3j7F9";
const char* ssid = "Galaxy Note10";
const char* password = "12345678";
String town="1";
int level = 5;
int applience = 16;    //D0
int SystemOperation;
const int trigPin = 4;  //D2
const int echoPin = 5;  //D1
long duration;
int tank_level;
String serverName = "http://solveswiftly.com/device_actions.php";
String requestHTTP="";                       
const long interval = 5000;
unsigned long previousMillis = 0;
String outputsState;

void setup() 
{
  Serial.begin(115200);  
  pinMode(applience,OUTPUT);
  pinMode(level,INPUT);
  pinMode(trigPin, OUTPUT); // Sets the trigPin as an Output
  pinMode(echoPin, INPUT); // Sets the echoPin as an Input
  WiFi.mode(WIFI_STA);
  WiFiMulti.addAP(ssid, password);
  while((WiFiMulti.run() == WL_CONNECTED)) 
  { 
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("Connected to WiFi");
}
void loop() 
{
  String outputResponse ="";
  unsigned long currentMillis = millis();
  if(currentMillis - previousMillis >= interval)
  {
    if ((WiFiMulti.run() == WL_CONNECTED)) 
    {
      digitalWrite(echoPin, LOW);
      pulseIn(echoPin, LOW);
      digitalWrite(trigPin, LOW);
      delayMicroseconds(2);
      digitalWrite(trigPin, HIGH);
      delayMicroseconds(10);
      digitalWrite(trigPin, LOW);
      duration = pulseIn(echoPin, HIGH);
      Serial.print("DURATION : ");
      Serial.println(duration);
      if(duration < 1500)
      {
        Serial.println("TANK FULL");
      }
      else
      {
        Serial.println("FILLING.........");
      }
      tank_level = (duration*.0343)/2; 
      Serial.println("tank_level: "+String(tank_level)); 
    
      requestHTTP = serverName+"?action=outputs_state&d_name=Device1";
      outputResponse = httpGETRequest(requestHTTP);
      Serial.println("----------------------");
      Serial.println(outputResponse);
      JSONVar myGetObject = JSON.parse(outputResponse);
      if (JSON.typeof(myGetObject) == "undefined") 
      {
         Serial.println("Parsing input failed!");
            return;
      }
      Serial.print("JSON object = ");
      Serial.println(myGetObject);
      JSONVar keys = myGetObject.keys();
      for (int i = 0; i < keys.length(); i++) 
      {
        JSONVar value = myGetObject[keys[i]];
        Serial.print("GPIO: ");
        Serial.print(keys[i]);
        Serial.print(" - SET to: ");
        Serial.println(value);
         SystemOperation = atoi(value);
      }
      if(SystemOperation == 1)
      {
        if(tank_level >25 )
        {
          Serial.println("DEVICE : ON - SUPPLY : ON - TANK LEVEL : LOW");
          requestHTTP = String("api_key=")+apiKeyValue+"&action="+"system_on_state" + "&tid=" + town +"&applience_state=1"+"&did=1"+"&Tank_level="+String(tank_level); //deviceid,
          Serial.println("Devicce State : oN");
          digitalWrite(applience,HIGH);
          Serial.println(requestHTTP);
        }
        else
        {
          Serial.println("DEVICE : OFF - SUPPLY : OFF - TANK LEVEL : FULL");
          digitalWrite(applience,LOW);        
          requestHTTP = String("api_key=")+apiKeyValue+"&action="+"system_on_state" + "&tid=" + town +"&applience_state=0"+"&did=1"+"&Tank_level="+String(tank_level);
          Serial.println(requestHTTP);
        }
         
        outputResponse = httpPOSTRequest(serverName,requestHTTP);
        JSONVar myPOSTobject = JSON.parse(outputResponse);
        if (JSON.typeof(myPOSTobject) == "undefined") 
        {
           Serial.println("Parsing input faileddddddddd!");
              return;
        }
        Serial.print("JSON object = ");
        Serial.println(myPOSTobject);
      }
      else
      {
        digitalWrite(applience,LOW);
        Serial.println("TANK STATUS :");
        Serial.println(tank_level);
        requestHTTP = String("api_key=")+apiKeyValue+"&action="+"Tank_Status" + "&did=1"+"&applience_state=0"+"&Tank_level=100"+"did=1";
      }     
      outputResponse = httpPOSTRequest(serverName,requestHTTP);     
      JSONVar myPOSTobject = JSON.parse(outputResponse);
      if (JSON.typeof(myPOSTobject) == "undefined") 
      {
        Serial.println("Parsing input failed!");
        return;
      }
       Serial.print("JSON object = ");
       Serial.println(myPOSTobject);
       previousMillis = currentMillis;
    }
    else 
    {
      Serial.println("WiFi Disconnected");
    }
  }
}
String httpPOSTRequest(String serverName,String postdata ) 
{
  WiFiClient client;
  HTTPClient http;
  http.begin(client,serverName);
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");
  int httpResponseCode = http.POST(postdata) ;
  String payload = ""; 
  Serial.print("Response code : ");
  Serial.println(httpResponseCode);
  if (httpResponseCode>0) 
  {
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    payload = http.getString();
    Serial.println(payload);
  }
  else 
  {
    Serial.print("Error code: ");
    Serial.println(httpResponseCode);
  }
  http.end();
  return payload;
}
String httpGETRequest(String serverName) {
  WiFiClient client;
  HTTPClient http;
  http.begin(client,serverName);
  int httpResponseCode = http.GET();
  String payload = ""; 
  if (httpResponseCode>0) {
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    payload = http.getString();
    Serial.println(payload);
  }
  else {
    Serial.print("Error code: ");
    Serial.println(httpResponseCode);
  }
  http.end();
  return payload;
}

