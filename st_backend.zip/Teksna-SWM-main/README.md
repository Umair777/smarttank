# Teksna-WaterSupply
Teksna Smart Water Supply System is combination of all wireless technologies &amp; AI integrated chips that runs on our citywise Teksna Wireless Intelligent Network with our extreme encryption in communications which enables people to get smartly assisted at operating thier domestic &amp; Buildings Water Supply, Solving major problems such as Water Wastage, Motors Operation cost and their life-span, improves Water Quality with our Water Filteration methods and it gives savings in your Electricity Bills stopping any energy& water wastage.

Files workflow : 

1) index.php --> LOGIN 
2) device_actions.php --> contains Backend GET/POST API fuctionalities(login confirmation, dashboard data fetching and submitting data from Esp32 to the Database)
3) device_database.php --> Sql querries in php to the database with its credentials.
4) variables.php 
5) data.php --> dashboard data assigned from variables.php
6) water.png
