<?php
    include_once('device_database.php');
    $api_key_value = "tPmAT5Ab3j7F9"; //API KEY for Users device
    $pass = $passErr = $e = $email = $emailErr = $api_key = $action = $id = $state = $device_name = $result =  "";
    
    if ($_SERVER["REQUEST_METHOD"] == "GET")    //ESP API for updating system status from dashboard
    {
        $action = test_input($_GET["action"]);
        if ($action == "system_state_update") 
        {
            $id = test_input($_GET["id"]);
            $state = test_input($_GET["system_state"]);
            $result = updateDevice($id, $state);
            echo json_encode($state);
            echo $result;
        }
        else if($action == "outputs_state") //fetch device details from the server to the ESP
        {
            
            $device_name = test_input($_GET["d_name"]);
            
            $result = getAllOutputStates($device_name);
            if ($result)
            {
                while ($row = $result->fetch_assoc()) 
                {
                    $rows[$row["device_name"]] = $row["device_state"]; //for example. [mydev : 1]
                }
            }
            echo json_encode($rows);
            //$result = getBoard($board);
            //if($result->fetch_assoc()) {
            //   updateLastBoardTime($board);
            //}
        }
        else 
        {
        //    echo "NO GET REQ";
        }
     
    }
    else if ($_SERVER["REQUEST_METHOD"] == "POST") //LOgin confirmation
    {
        if (empty($_POST["email"])) 
        {
            $emailErr = "*Email is required*";
            if (empty($_POST["pass"])) 
            {
                echo "NO EMAIL DETECTED";
                $passErr = "*pass is required*";
                return $result;
            }
            return $result;
        } 
        else 
        {
            if (empty($_POST["pass"])) 
            {
                $passErr = "*pass is required*";
                //return $result;
            }
            $pass = test_input($_POST["pass"]);
            $email = test_input($_POST["email"]);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
            {
                $emailErr = "*Invalid email format*";
                //return $result;
            }
            else
            {
                $conn = new mysqli($servername, $username, $password, $dbname);                
                if ($conn->connect_error) 
                {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT *  FROM Users WHERE email='" . $email . "'";
                
                if ($result = $conn->query($sql)) 
                {
                    while ($row = $result->fetch_assoc()) 
                    {
                        
                        $ID = $row["id"];
                        $e = $row["email"];
                        $p = $row["Password"];
                        $t = $row["town"];
                        //include_once('variables.php');
                      //  echo $email;
                    //    echo $ID;
                        
                    }
                    
                    
                }
                else 
                {
                    echo "ERRRRRRRR";
                    return false;
                }
                if($e == $email)
                {
                    if($p == $pass)
                    {
                      
                        echo "<script>
                        var userId = $ID;
                        var userTown = $t;
                        window.location.href='http://www.solveswiftly.com/data.php?id='+userId+'&town='+userTown;
                         </script>";
                         
                    }
                    else
                    {
                        $passErr = "Incorrect Password";
                        return $result;
                    }
                }
                else
                {
                    $emailErr = "*Incorect Email*";
                    return $result;
                }
                $conn->close();
            }
        return $result;
        }

        $api_key = test_input($_POST["api_key"]);
        if($api_key == "system_on_state") //API for updataing database from ESP device sensors.
        {
            $id = test_input($_POST["tid"]);
            $value1 = test_input($_POST["supply_state"]);
            $applience = test_input($_POST["applience_state"]);
            $devId = test_input($_POST["did"]);
            $tank = test_input($_POST["Tank_level"]);
                                                                                
            $conn = new mysqli($servername, $username, $password, $dbname);         // Create connection
            if ($conn->connect_error)                                               // Check connection
            {
                die("Connection failed: " . $conn->connect_error);
            } 
            $sql = "UPDATE Towns SET supply_state ='" . $value1 . "' WHERE id='". $id .  "'";
            if ($conn->query($sql) === TRUE) 
            {
                echo "Supply status updated successfully";
            } 
            else 
            {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $sql2 = "UPDATE Users SET device_state ='" . $applience . "',Tank_quantity ='" . $tank . "' WHERE id ='". $devId .  "'";
            if ($conn->query($sql2) === TRUE) 
            {
                echo "Applience status updated successfully";
            } 
            else 
            {
                echo "Error: " . $sql2 . "<br>" . $conn->error;
            }
            $conn->close();
        }
        else if($api_key == "Tank_Status")
        {
            $tank = test_input($_POST["Tank_level"]);
            $devId = test_input($_POST["did"]);
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) 
            {
                die("Connection failed: " . $conn->connect_error);
            } 
            $sql = "UPDATE Users SET Tank_quantity ='" . $tank . "' WHERE id='". $devId .  "'";
            if ($conn->query($sql) === TRUE) 
            {
                echo "Supply status updated successfully";
            } 
            else 
            {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $conn->close();
        }
        else
        {
            echo "Wrong API Key provided.";
        }
    }
    else 
    {
        echo "No data posted with HTTP POST.";
    }
    
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>
