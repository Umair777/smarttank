<?php 
include_once('device_actions.php');                                 //contains necesaaary API fuctions for communicating with the DB
?>
<!DOCTYPE HTML>  
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">         
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="teksna_waters_style.css">          <! -- styling the HTML from teksna_waters_style.css -->
</head>
<body>  
<h2>Teksna Smart Water System</h2><br><br>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  E-mail: <input type="text" name="email" value="<?php echo $email;?>">     <! -- "name" attribute will be used for validation -->
  <span class="error" style="color:red;"><?php echo $emailErr;?></span> <br><br>                       <! -- value to "emailErr" is assigned from device_actions.php-->
  Password : <input type="text" name="pass" value="<?php echo $pass;?>" >     <! -- "name" attribute will be used for validation -->
  <span class="error" style="color:red;"><?php echo $passErr;?> </span>                        <! -- value to "emailErr" is assigned from device_actions.php-->
  <br><br>
  <input type="submit" onclick=login(this) name="submit" value="Submit">  
</form>
<br>
<a href="https://solveswiftly.com/resetpassword.php">Forgot Password      </a><br><br>
<a href="https://solveswiftly.com/registration.php">Not Registered ?</a><br>
</body>
</html>