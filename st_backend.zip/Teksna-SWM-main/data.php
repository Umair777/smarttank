<?php 
    include_once('device_database.php');                        //contains DB credentials and necessary functions to Query the DB
    include_once('variables.php');                              //UserID & PASSWORD based result, Tank and Supply Status are assigned here
    
?>

<!DOCTYPE HTML>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="teksna_waters_style.css">
        <title>Teksna Water Control</title>
    </head>
    <body>
    <h2>Smart Water System </h2>
    <?php echo $button; ?> //refer variables.php
    <br><br>
    <?php echo $watersupply; ?> //refer variables.php
    <h1>Tank Live Status</h1>   //refer variables.php hidden image carries tank percentage for the progressive bar.
    <div id="myProgress">
        <div id="myBar">0%</div>
    </div>
    <br>
    <?php echo $tank; ?>
    
    <script>          
        var i = 0;
        function move(element) 
        {
            
            console.log(element.id);
            if (i == 0) 
            {
                i = 1;
                var elem = document.getElementById("myBar");
                var width = 0;
                var id = setInterval(frame, 10);
                function frame() 
                {
                    if (width >= element.id) 
                    {
                        clearInterval(id);
                        i = 0;
                    } 
                    else 
                    {
                        width++;
                        elem.style.width = width + "%";
                        elem.innerHTML = width  + "%";
                    }
                }
            }
        }
        function update_device(element) //JS for html_switch_buttons in variables.php for the system status on the dasboard 
        {
            console.log(element.id);
            console.log("updating device...");
            var xhr = new XMLHttpRequest();             
            if(element.checked)
            {
                xhr.open("GET", "device_actions.php?action=system_state_update&id="+element.id+"&system_state=1", true);
            }
            else
            {
                xhr.open("GET", "device_actions.php?action=system_state_update&id="+element.id+"&system_state=0", true);
            }
                xhr.send();
                console.log("Sent button status");
        }
    </script>
</body>
</html>
