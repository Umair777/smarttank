<?php
if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        $ID = $_GET["id"];
        $TOWN_ID = $_GET["town"];
    }
    $result = getUsersById($ID);
    
    if ($result) 
    {
        while ($row = $result->fetch_assoc()) 
        {
            if ($row["device_state"] == "1")
            {
                $button_checked = "checked";
            }
            else 
            {
                $button_checked = "";
            }
            $button .= '<h3>' . $row["device_name"].'<br>' .'<label class="switch"><input type="checkbox" onchange="update_device(this)" id="' . $row["id"] . '" ' . $button_checked . '><span class="slider"></span></label>'.'<br>'.'<br><br>'.'Water in Tank : '. $row["Tank_quantity"] .'%';
            
            $tank .= '<img src="transparent.png" hidden onload="move(this)" id="' . $row["Tank_quantity"] . '">'; 
        }
      
    }
    $town_id = $TOWN_ID;
    $result1 = getDetailsByTown($town_id);
    
    if ($result1) 
    {
        while ($row = $result1->fetch_assoc()) 
        {      
            $watersupply .= '<h3> SUPPLY : ' . $row["supply_state"].'<br>'; 
        }
     }
?>